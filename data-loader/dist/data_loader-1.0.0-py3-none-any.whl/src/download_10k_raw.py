import pandas as pd
import numpy as np
import requests
from requests.exceptions import SSLError
import click
from datetime import datetime
import logging
from bs4 import BeautifulSoup
import re
import os
import sys
from azure.storage.filedatalake import DataLakeServiceClient
import configparser
from html_table_parser.parser import HTMLTableParser

from .util.config import PipelineConfiguration


logging.basicConfig(level=logging.INFO)
log = logging.getLogger("DSAI-DATALOADER")

def _validate_choices(options):
    
    def func(value):
        if value not in options:
            raise click.BadParameter(
                "Possible choices are: {}.".format(", ".join(options))
            )
        return value

    return 

def _validate_date(ctx, param, value):
    if value == "":
        return value
    try:
        value = pd.to_datetime(value, format='%m-%d-%Y')
        return value
    except ValueError:
        raise click.BadParameter("format must be in format '%m-%d-%Y'")  

def make_master_index_urls(pipeline_config: PipelineConfiguration):
    """This function creates URLs for master index 
    files for every given quarter and year. Either a start date or an end date
    could be given or both."""

    start_date = pipeline_config.specs.start_date
    end_date = pipeline_config.specs.end_date
    edgar_prefix = pipeline_config.specs.edgar_prefix
    
    quarters= ['QTR1', 'QTR2', 'QTR3', 'QTR4']
    if start_date and end_date:
        start_date_converted = datetime.strptime(start_date, '%m-%d-%Y')
        end_date_converted = datetime.strptime(end_date, '%m-%d-%Y')

        start_year = start_date_converted.year 
        end_year = end_date_converted.year        
        year = range(start_year, end_year + 1)
        history = list((y, q) for y in year for q in quarters)
        logging.info('Creating master index file URLs from %s to %s' % (start_date_converted.date(), end_date_converted.date()))
        return [(edgar_prefix + "edgar/full-index/%s/%s/master.idx" % (h[0], h[1]))
            for h in history]
    else:
        year = [i for i in [start_date, end_date] if i][0]
        print(year)
        _year = year.year 
        quarter = 'QTR' + str(year.quarter)
        history = list((_year, quarter) for q in quarters)
        logging.info('Creating master index files URLs for %s' % (_year))
        return [(edgar_prefix + "edgar/full-index/%s/%s/master.idx" % (h[0], h[1])) for h in history]


    
def get_form_type(data, form_type):
    """This function creates a dataframe to contain each 
    filing information and gives a name to each filing"""
    
    master_data = pd.DataFrame(data)
    master_data.columns = ['CIK', 'company_name', 'form_id', 'date', 'file_url']
    master_data['date'] = pd.to_datetime(master_data['date'])
    master_data['file_name'] = master_data['file_url'].str[-24:]
    master_data_ = master_data.loc[master_data['form_id'] == form_type]
    return master_data_ 


def get_Bermuda_companies(pipeline_config: PipelineConfiguration):
    user_agent = pipeline_config.specs.user_agent
    try:
        pages = np.arange(0, 1600, 100)
        headers = {'User-Agent': user_agent}
        Companies = []

        for page in pages:
            xhtml = requests.get("https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&State=D0&owner=exclude&match=&start=" 
                             + str(page) + "&count=100&hidefilings=0", headers=headers).text
        
            p = HTMLTableParser()
            p.feed(xhtml)
            data = p.tables
            e = pd.DataFrame(np.column_stack(data))
            e.columns = e.iloc[0]
            e = e[1:]
            Companies.append(e)
        final = pd.concat(Companies)
        log.info(final)
        return final
    except Exception:
        log.exception("An error occured")


def read_master_index(urls, pipeline_config: PipelineConfiguration):
    """This function reads each master index file and records each filing information into a dataframe"""
    user_agent = pipeline_config.specs.user_agent
    edgar_prefix = pipeline_config.specs.edgar_prefix
    try:
        master_dataset = []
        for url in urls:
            headers = {'User-Agent': user_agent}
            content = requests.get(url, headers=headers).content
            with open('master.text', 'wb') as f:
                f.write(content)
            with open('master.text', 'rb') as f:   #read the content of the text file
                byte_data = f.read()
        
            data = byte_data.decode('latin-1').split('  ')  #decode the byte data
            master_data = []

            for index, item in enumerate(data):
                if 'ftp://ftp.sec.gov/edgar/' in item:
                    start_ind = index
            data_format = data[start_ind + 1:]  #create a new list that removes junk
            for index, item in enumerate(data_format):
                if index== 0:
                    clean_item_data = item.replace('\n', '|').split('|')
                    clean_item_data = clean_item_data[8:]
                else:
                    clean_item_data = item.replace('\n', '|').split('|')

                for index, row in enumerate(clean_item_data):
                    if '.txt' in row:   #when you find the text file
                        mini_list = clean_item_data[(index - 4): index + 1]
                        if len(mini_list) !=0:
                            mini_list[4] = edgar_prefix + mini_list[4]
                            master_data.append(mini_list)
            master_dataset.append(get_form_type(master_data, '10-K'))
        logging.info('Pulling 10-K filings')
    
        final_master = pd.concat(master_dataset)
        compare = get_Bermuda_companies(pipeline_config)
        final_master_ = pd.merge(final_master, compare, on='CIK', how='left').drop(['Company', 'State/Country'], axis=1)
        final = final_master_.sort_values(by='date')
        final_ = final.set_index('date')
        return final_
    except Exception:
        logging.exception("An error occured")


def extract_10_K_items(url, user_agent):
    headers = {"User-Agent": user_agent}
    try:
        r = requests.get(url, headers=headers)
        raw_10k = r.text
        doc_start_pattern = re.compile(r'<DOCUMENT>')
        doc_end_pattern = re.compile(r'</DOCUMENT>')
        type_pattern = re.compile(r'<TYPE>[^\n]+')
        doc_start_is = [x.end() for x in doc_start_pattern.finditer(raw_10k)]
        doc_end_is = [x.start() for x in doc_end_pattern.finditer(raw_10k)]
        doc_types = [x[len('<TYPE>'):] for x in type_pattern.findall(raw_10k)]
    
        document = {}
        for doc_type, doc_start, doc_end in zip(doc_types, doc_start_is, doc_end_is):
            if doc_type == '10-K':
                document[doc_type] = raw_10k[doc_start:doc_end]
            
    
        regex = re.compile(r'>?(ITEM|Item)(\s|&#160;|&nbsp;|&#xa0;)([1-9]+|1A|1B|7A)(\.+|:){0,2}')
    
    
    ### To-Do; if regex is not found, pass
        try:
            matches = regex.finditer(document['10-K'])
            matches_df = pd.DataFrame([(x.group(), x.start(), x.end()) for x in matches])
            matches_df.columns = ['item', 'start', 'end']
    
            matches_df.replace('&#160;|&nbsp;|\.|>|\s|&#xa0;', '',regex=True,inplace=True)
            new_df = matches_df.sort_values('start', ascending=True).drop_duplicates(subset=['item'], keep='last')

            table = []
            for i in range(len(new_df)-1):
                table.append(document['10-K'][new_df['start'].iloc[i]:new_df['start'].iloc[i+1]])
    
            new_table =[]
            for i in table:
                new_table.append(BeautifulSoup(i, 'lxml'))
        
            newer_table = []
            for i in new_table:
                newer_table.append(i.get_text("\n\n"))
        
            final_df = pd.DataFrame(newer_table)
            final_df.columns = ['Item Contents']
            final_df['file_url'] = url
            return final_df
    
    #need to resolve this exception
        except (ValueError, KeyError) as e:
            logging.exception('An error occurred: 10-K file could not be parsed')
    
    except Exception:
        logging.exception(f'An error occured while parsing this file, {url}')


def upload_file_to_storage(df, pipeline_config: PipelineConfiguration):

    container_name = pipeline_config.specs.container_name
    storage_dir_name = pipeline_config.specs.storage_dir_name
    file_name = pipeline_config.specs.file_name

    try:
        storage_account_name = pipeline_config.specs.storage_account_name
        account_access_key = pipeline_config.specs.account_access_key

        service_client = DataLakeServiceClient(
                            account_url=f"https://{storage_account_name}.dfs.core.windows.net", 
                            credential=account_access_key
                        )

        file_system_client = service_client.get_file_system_client(file_system=container_name)
        directory_client = file_system_client.get_directory_client(f"{storage_dir_name}")
        
        file_client = directory_client.create_file(f"{file_name}")
        f = open('10k_files_raw.csv','r')

        file_contents = f.read()

        file_client.upload_data(file_contents, overwrite=True)

        f.close()

        logging.info(f"{file_name} uploaded successfully")
    except Exception:
        logging.exception(f"An error occurred while uploading {file_name} to the azure data lake storage")

                
def executeDataDownloader(pipeline_config: PipelineConfiguration):
        start_date = pipeline_config.specs.start_date
        end_date = pipeline_config.specs.end_date
        user_agent = pipeline_config.specs.user_agent
        log.info(
            f'start_date: {start_date}; end_date: {end_date}; user_agent: {user_agent}'
        )
        try:
            master_index_urls = make_master_index_urls(pipeline_config)
            log.info(f'master_index_urls: {master_index_urls}')
            df = read_master_index(master_index_urls, pipeline_config)
            log.info('===== master dataframe =====')
            log.info(df)
            log.info('============================\n\n\n')
            if start_date and end_date:
                df = df[start_date : end_date]
                log.info('===== start -> enddate dataframe =====')
                log.info(df)
                log.info('============================\n\n\n')

            mini_df = df.reset_index()
            no_of_files = len(mini_df['file_url'])
            
            log.info(f'Number of files to be extracted: {no_of_files}')

            if no_of_files > 0:
                urls = df['file_url']
                dataf = []
                for url in urls:
                    parsed = extract_10_K_items(url, user_agent)
                    dataf.append(parsed)    
                new = pd.concat(dataf)
                new_df = pd.merge(new, df, on='file_url', how='left').drop(['form_id', 'file_name'], axis=1)
                new_df['Items'] = new_df['Item Contents'].str[:8]
                new_df['Item Contents'] = new_df['Item Contents'].str[8:]
                new_df = new_df.apply(lambda x : x.str.replace('\n', '\\n'))
                new_df = new_df[['CIK', 'company_name', 'Items', 'Item Contents', 'file_url']]
                new_df.to_csv('10k_files_raw.csv')
                #upload_file_to_storage() TODO: Fix file upload
                #return new_df
            else:
                log.info('No files found for specified period')

        except Exception as e:
                log.error('Unexpected Trying Procession 10k File for Bermuda')
       

@click.command()
@click.option("-f", "--config-format", type=click.Choice(["yaml", "json"]), help="input config file format",)
@click.option("-i", "--input", type=click.Path(exists=False), help="input file")
def runDataDownloader(config_format, input):
    log.info('Running 10k Document Downloader ...')

    if input is None:
         input = click.prompt(
                    "please specific input config file",
                    default="default.yaml",)

    if config_format is None:
        valid_config_formats = ["json", "yaml"]
        _, config_format = os.path.splitext(input)
        log.info(f'config format: {config_format}')
        config_format = config_format[1:].lower()
        if config_format not in valid_config_formats:
                config_format = click.prompt(
                "Couldn't ascertain one of [%s] from file name. Convert to"
                % ", ".join(valid_config_formats),
                value_proc=_validate_choices(["yaml", "json"]),
                default="yaml",
            )

    if config_format == "yaml":
        pipeline_config = PipelineConfiguration.load(input)
        log.info(pipeline_config)
        executeDataDownloader(pipeline_config)
    elif config_format == "json":
        #TODO: parse it to YAML
        pass

if __name__ == '__main__':
    runDataDownloader()