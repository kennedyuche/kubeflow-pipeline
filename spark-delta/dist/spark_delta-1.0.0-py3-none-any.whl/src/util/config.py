from typing import List, Dict, Optional
from pydantic import BaseModel
from pydantic_yaml import YamlModel
import logging
import pathlib
import os


logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

log = logging.getLogger("DSAI-Config")


class Specs(BaseModel):
    container_name: str
    storage_account_name: str
    account_access_key: str
    storage_dir_name: str
    file_name: str
    start_date: str
    end_date: str
    user_agent: str
    edgar_prefix: str = "https://www.sec.gov/Archives/"


class PipelineConfiguration(YamlModel):
    name: Optional[str]
    kind: Optional[str] = "RawDataDownloader"
    specs: Specs

    @classmethod
    def load(cls, input_path: str):
        configuration_file = pathlib.Path(input_path)
        with configuration_file.open() as fp:
            return PipelineConfiguration.parse_raw(fp, proto="yaml")
