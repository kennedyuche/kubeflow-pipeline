import logging
import re
import os
import sys
import click

from .util.config import PipelineConfiguration

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("DSAI-DELTAWRITER")


def _validate_choices(options):
    
    def func(value):
        if value not in options:
            raise click.BadParameter(
                "Possible choices are: {}.".format(", ".join(options))
            )
        return value
    return 

def execute_spark_delta_writer( pipeline_config :PipelineConfiguration ):
    pass

@click.command()
@click.option("-f", "--config-format", type=click.Choice(["yaml", "json"]), help="input config file format",)
@click.option("-i", "--input", type=click.Path(exists=False), help="input file")
def runDataDownloader(config_format, input):
    log.info('Running Spark Data Writer to Table ...')

    if input is None:
         input = click.prompt(
                        "please specific input config file",
                        default="default.yaml",
                    )

    if config_format is None:
        valid_config_formats = ["json", "yaml"]
        _, config_format = os.path.splitext(input)
        log.info(f'config format: {config_format}')
        config_format = config_format[1:].lower()
        if config_format not in valid_config_formats:
                config_format = click.prompt(
                "Couldn't ascertain one of [%s] from file name. Convert to"
                % ", ".join(valid_config_formats),
                value_proc=_validate_choices(["yaml", "json"]),
                default="yaml",
            )

    if config_format == "yaml":
        pipeline_config = PipelineConfiguration.load(input)
        log.info(pipeline_config)
        execute_spark_delta_writer(pipeline_config)
    elif config_format == "json":
        #TODO: parse it to YAML
        pass

if __name__ == '__main__':
    runDataDownloader()